-- SpendWise database schema (MySQL 8.0+)
-- This schema is for a future PHP/MySQL backend.
-- The included HTML/CSS/JavaScript prototype uses browser localStorage,
-- so it does not connect to this database by itself.

CREATE DATABASE IF NOT EXISTS spendwise_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE spendwise_db;

CREATE TABLE IF NOT EXISTS users (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS categories (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id BIGINT UNSIGNED NULL,
  name VARCHAR(80) NOT NULL,
  type ENUM('income','expense') NOT NULL,
  icon VARCHAR(20) DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  CONSTRAINT fk_categories_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY uq_category_user_name_type (user_id, name, type)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS transactions (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id BIGINT UNSIGNED NOT NULL,
  category_id BIGINT UNSIGNED NULL,
  title VARCHAR(100) NOT NULL,
  type ENUM('income','expense') NOT NULL,
  amount DECIMAL(12,2) NOT NULL,
  transaction_date DATE NOT NULL,
  notes VARCHAR(300) DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  CONSTRAINT chk_transaction_amount CHECK (amount > 0),
  CONSTRAINT fk_transactions_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_transactions_category FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL,
  INDEX idx_transactions_user_date (user_id, transaction_date),
  INDEX idx_transactions_user_type (user_id, type)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS monthly_budgets (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id BIGINT UNSIGNED NOT NULL,
  budget_month DATE NOT NULL COMMENT 'Use the first day of the target month',
  amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  CONSTRAINT chk_budget_amount CHECK (amount >= 0),
  CONSTRAINT fk_budgets_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY uq_budget_user_month (user_id, budget_month)
) ENGINE=InnoDB;

-- Optional starter categories. These are global categories (user_id = NULL).
INSERT IGNORE INTO categories (user_id, name, type, icon) VALUES
(NULL, 'Food & Dining', 'expense', '🍜'),
(NULL, 'Transportation', 'expense', '🚌'),
(NULL, 'Shopping', 'expense', '🛍️'),
(NULL, 'Bills & Utilities', 'expense', '💡'),
(NULL, 'Health', 'expense', '💊'),
(NULL, 'Education', 'expense', '📚'),
(NULL, 'Entertainment', 'expense', '🎬'),
(NULL, 'Personal Care', 'expense', '🧴'),
(NULL, 'Other', 'expense', '•'),
(NULL, 'Salary', 'income', '💼'),
(NULL, 'Allowance', 'income', '💵'),
(NULL, 'Freelance', 'income', '💻'),
(NULL, 'Business', 'income', '🏪'),
(NULL, 'Gift', 'income', '🎁'),
(NULL, 'Investment', 'income', '📈');

-- Example monthly summary query after a user has transactions:
-- Replace 1 with the desired users.id.
-- SELECT
--   COALESCE(SUM(CASE WHEN type='income' THEN amount ELSE 0 END),0) AS income_total,
--   COALESCE(SUM(CASE WHEN type='expense' THEN amount ELSE 0 END),0) AS expense_total
-- FROM transactions
-- WHERE user_id = 1
--   AND transaction_date >= DATE_FORMAT(CURRENT_DATE, '%Y-%m-01')
--   AND transaction_date < DATE_ADD(DATE_FORMAT(CURRENT_DATE, '%Y-%m-01'), INTERVAL 1 MONTH);
