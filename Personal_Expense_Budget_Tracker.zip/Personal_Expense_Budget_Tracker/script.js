/* SpendWise prototype
   This front-end demo stores data in this browser's localStorage.
   It does not connect to the MySQL schema until a backend is added.
*/
(() => {
  "use strict";
  const STORAGE_KEY = "spendwise_transactions_v1";
  const BUDGET_KEY = "spendwise_monthly_budget_v1";
  const CATEGORIES = {
    expense: ["Food & Dining", "Transportation", "Shopping", "Bills & Utilities", "Health", "Education", "Entertainment", "Personal Care", "Other"],
    income: ["Salary", "Allowance", "Freelance", "Business", "Gift", "Investment", "Other"]
  };
  const COLORS = ["#155eef", "#7f56d9", "#f79009", "#12b76a", "#f04438", "#06aed4", "#ee46bc", "#667085", "#a4bcfd"];
  const ICONS = {"Food & Dining":"🍜","Transportation":"🚌","Shopping":"🛍️","Bills & Utilities":"💡","Health":"💊","Education":"📚","Entertainment":"🎬","Personal Care":"🧴","Other":"•","Salary":"💼","Allowance":"💵","Freelance":"💻","Business":"🏪","Gift":"🎁","Investment":"📈"};
  const $ = id => document.getElementById(id);
  const money = amount => new Intl.NumberFormat("en-PH", {style:"currency",currency:"PHP"}).format(Number(amount)||0);
  const shortMoney = amount => "₱" + new Intl.NumberFormat("en-PH",{maximumFractionDigits:0}).format(Number(amount)||0);
  const dateISO = d => { const x = new Date(d); return `${x.getFullYear()}-${String(x.getMonth()+1).padStart(2,"0")}-${String(x.getDate()).padStart(2,"0")}`; };
  const todayISO = () => dateISO(new Date());
  const parseDate = value => new Date(`${value}T12:00:00`);
  const displayDate = value => parseDate(value).toLocaleDateString("en-PH",{month:"short",day:"numeric",year:"numeric"});
  const monthKey = value => value.slice(0,7);
  const thisMonth = () => todayISO().slice(0,7);
  const escapeHTML = value => String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  const makeId = () => (crypto && crypto.randomUUID) ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  const demoTransactions = () => {
    const now = new Date(), ym = thisMonth();
    const dateAt = day => `${ym}-${String(day).padStart(2,"0")}`;
    const samples = [
      ["Monthly allowance","Allowance",4500,"income",dateAt(2),"Monthly allowance received"],
      ["Grocery shopping","Food & Dining",680.50,"expense",dateAt(3),"Food and household items"],
      ["Jeepney fare","Transportation",180,"expense",dateAt(4),"Daily commute"],
      ["Freelance project","Freelance",2200,"income",dateAt(5),"Small web design task"],
      ["Mobile load","Bills & Utilities",199,"expense",dateAt(6),"Prepaid load"],
      ["Lunch with friends","Food & Dining",260,"expense",dateAt(8),"Lunch"],
      ["School supplies","Education",345,"expense",dateAt(9),"Notebooks and pens"],
      ["Online purchase","Shopping",550,"expense",dateAt(10),"Personal item"],
      ["Part-time work","Salary",1800,"income",dateAt(12),"Part-time income"],
      ["Electricity share","Bills & Utilities",620,"expense",dateAt(14),"Household bills"]
    ];
    return samples.map(s=>({id:makeId(),title:s[0],category:s[1],amount:s[2],type:s[3],date:s[4],notes:s[5],createdAt:now.toISOString()}));
  };
  let transactions = loadTransactions();
  let monthlyBudget = loadBudget();
  let toastTimer;
  function loadTransactions(){
    try { const value=JSON.parse(localStorage.getItem(STORAGE_KEY)); if(Array.isArray(value)) return value; } catch(e){}
    const demo=demoTransactions(); localStorage.setItem(STORAGE_KEY,JSON.stringify(demo)); return demo;
  }
  function loadBudget(){ const n=Number(localStorage.getItem(BUDGET_KEY)); return Number.isFinite(n)&&n>=0?n:10000; }
  function save(){ localStorage.setItem(STORAGE_KEY,JSON.stringify(transactions)); localStorage.setItem(BUDGET_KEY,String(monthlyBudget)); }
  function showToast(message){ const el=$("toast"); el.textContent=message; el.classList.add("show"); clearTimeout(toastTimer); toastTimer=setTimeout(()=>el.classList.remove("show"),2600); }
  function getCurrentMonth(type){ return transactions.filter(t=>monthKey(t.date)===thisMonth()&&(!type||t.type===type)); }
  function sum(items){return items.reduce((acc,t)=>acc+Number(t.amount||0),0);}
  function expensesForMonth(){return getCurrentMonth("expense");}
  function incomeForMonth(){return getCurrentMonth("income");}
  function getCategoryTotals(items){const map={};items.forEach(t=>map[t.category]=(map[t.category]||0)+Number(t.amount));return Object.entries(map).sort((a,b)=>b[1]-a[1]);}
  function iconFor(t){return ICONS[t.category]|| (t.type==="income"?"↗":"•");}
  function renderAll(){renderDashboard();renderTransactions();renderBudgets();renderReports();populateFilters();}
  function renderDashboard(){
    const inc=sum(incomeForMonth()), exp=sum(expensesForMonth()), left=monthlyBudget-exp;
    $("totalBalance").textContent=money(sum(transactions.filter(t=>t.type==="income"))-sum(transactions.filter(t=>t.type==="expense")));
    $("totalIncome").textContent=money(inc); $("totalExpenses").textContent=money(exp);
    $("budgetLeft").textContent=money(left); $("budgetProgress").style.width=`${monthlyBudget>0?Math.min(100,exp/monthlyBudget*100):exp>0?100:0}%`;
    $("budgetUsedLabel").textContent=`${monthlyBudget>0?Math.round(exp/monthlyBudget*100):exp>0?100:0}% used`;
    $("budgetLimitLabel").textContent=`of ${money(monthlyBudget)}`;
    $("budgetProgress").style.background=exp>monthlyBudget?"#f04438":"#7a5af8";
    renderOverviewChart($("overviewChart"),Number($("chartPeriod").value));
    renderDonut();
    const latest=[...transactions].sort((a,b)=>b.date.localeCompare(a.date)||String(b.createdAt).localeCompare(String(a.createdAt))).slice(0,5);
    $("recentTransactionsBody").innerHTML=latest.map(transactionRow).join("");
    $("recentEmpty").classList.toggle("hidden",latest.length>0);
  }
  function monthLabels(count){
    const arr=[]; const now=new Date();
    for(let i=count-1;i>=0;i--){const d=new Date(now.getFullYear(),now.getMonth()-i,1);arr.push({key:`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}`,label:d.toLocaleDateString("en-US",{month:"short"})});}
    return arr;
  }
  function renderOverviewChart(container,count){
    const labels=monthLabels(count);
    const data=labels.map(m=>({ ...m, income:sum(transactions.filter(t=>monthKey(t.date)===m.key&&t.type==="income")),expense:sum(transactions.filter(t=>monthKey(t.date)===m.key&&t.type==="expense"))}));
    const max=Math.max(1,...data.flatMap(d=>[d.income,d.expense]));
    container.innerHTML=data.map(d=>`<div class="bar-group"><div class="bar income" title="Income: ${money(d.income)}" style="height:${Math.max(d.income?3:1,d.income/max*100)}%"></div><div class="bar expense" title="Expenses: ${money(d.expense)}" style="height:${Math.max(d.expense?3:1,d.expense/max*100)}%"></div><span class="bar-label">${d.label}</span></div>`).join("");
  }
  function renderDonut(){
    const totals=getCategoryTotals(expensesForMonth()); const total=sum(expensesForMonth());
    $("donutTotal").textContent=shortMoney(total);
    if(!totals.length){$("categoryDonut").style.background="#eaecf0";$("categoryLegend").innerHTML='<p class="chart-placeholder">No expenses this month yet.</p>';return;}
    let acc=0;const stops=totals.map(([name,value],i)=>{const start=acc;acc+=value/total*100;return `${COLORS[i%COLORS.length]} ${start}% ${acc}%`;});
    $("categoryDonut").style.background=`conic-gradient(${stops.join(",")})`;
    $("categoryLegend").innerHTML=totals.slice(0,5).map(([name,value],i)=>`<div class="category-item"><i class="category-color" style="background:${COLORS[i%COLORS.length]}"></i><span class="category-name">${escapeHTML(name)}</span><strong class="category-amount">${money(value)}</strong></div>`).join("");
  }
  function transactionRow(t){
    const amount=`${t.type==="income"?"+":"−"}${money(t.amount)}`;
    return `<tr><td><div class="transaction-name"><span class="transaction-icon ${t.type==="income"?"income-bg":"expense-bg"}">${iconFor(t)}</span><span>${escapeHTML(t.title)}</span></div></td><td>${escapeHTML(t.category)}</td><td>${displayDate(t.date)}</td><td class="amount-cell ${t.type==="income"?"income-text":""}">${amount}</td><td><span class="type-badge ${t.type}">${t.type==="income"?"Income":"Expense"}</span></td><td><div class="row-actions"><button class="mini-action" data-edit="${escapeHTML(t.id)}" aria-label="Edit ${escapeHTML(t.title)}">Edit</button><button class="mini-action" data-delete="${escapeHTML(t.id)}" aria-label="Delete ${escapeHTML(t.title)}">Delete</button></div></td></tr>`;
  }
  function renderTransactions(){
    const query=($("transactionSearch").value||"").trim().toLowerCase(), type=$("typeFilter").value, category=$("categoryFilter").value;
    const rows=[...transactions].sort((a,b)=>b.date.localeCompare(a.date)||String(b.createdAt).localeCompare(String(a.createdAt))).filter(t=>(!query||`${t.title} ${t.category} ${t.notes||""}`.toLowerCase().includes(query))&&(type==="all"||t.type===type)&&(category==="all"||t.category===category));
    $("allTransactionsBody").innerHTML=rows.map(transactionRow).join("");
    $("transactionsEmpty").classList.toggle("hidden",rows.length>0);
    $("transactionCount").textContent=`${rows.length} transaction${rows.length===1?"":"s"}`;
  }
  function populateFilters(){
    const all=[...new Set([...CATEGORIES.expense,...CATEGORIES.income,...transactions.map(t=>t.category)])].sort();
    const current=$("categoryFilter").value;
    $("categoryFilter").innerHTML='<option value="all">All categories</option>'+all.map(c=>`<option value="${escapeHTML(c)}">${escapeHTML(c)}</option>`).join("");
    if(all.includes(current))$("categoryFilter").value=current;
    updateCategoryOptions();
  }
  function updateCategoryOptions(selected){
    const type=document.querySelector('input[name="transactionType"]:checked').value;
    const old=selected||$("transactionCategory").value;
    const cats=[...new Set([...CATEGORIES[type],...transactions.filter(t=>t.type===type).map(t=>t.category)])];
    $("transactionCategory").innerHTML=cats.map(c=>`<option value="${escapeHTML(c)}">${escapeHTML(c)}</option>`).join("");
    if(cats.includes(old))$("transactionCategory").value=old;
  }
  function renderBudgets(){
    const exp=sum(expensesForMonth()), remaining=monthlyBudget-exp;
    $("budgetPageLimit").textContent=money(monthlyBudget);$("budgetPageSpent").textContent=money(exp);$("budgetPageRemaining").textContent=money(remaining);
    $("budgetPageSpentNote").textContent=`${expensesForMonth().length} expense${expensesForMonth().length===1?"":"s"} recorded this month`;
    const totals=getCategoryTotals(expensesForMonth());
    const categories=[...new Set([...CATEGORIES.expense,...totals.map(t=>t[0])])];
    $("budgetList").innerHTML=categories.map((name,i)=>{
      const spent=(totals.find(t=>t[0]===name)||[])[1]||0;
      const catBudget=monthlyBudget*(spent?spent/(exp||1):1/categories.length);
      const pct=monthlyBudget>0?Math.min(100,spent/catBudget*100):spent?100:0;
      return `<div class="budget-row"><div class="budget-row-title"><span class="transaction-icon">${ICONS[name]||"•"}</span><div><strong>${escapeHTML(name)}</strong><span>${spent?`${Math.round(pct)}% of estimated category allocation used`:"No spending recorded"}</span></div></div><div class="budget-track"><span class="${spent>catBudget?"over":""}" style="width:${pct}%"></span></div><div class="budget-row-amount"><strong>${money(spent)}</strong><small>spent</small></div></div>`;
    }).join("");
    $("budgetEmpty").classList.toggle("hidden",categories.length>0);
  }
  function renderReports(){
    const inc=sum(incomeForMonth()),exp=sum(expensesForMonth());
    $("reportIncome").textContent=money(inc);$("reportExpenses").textContent=money(exp);$("reportSavings").textContent=money(inc-exp);
    renderOverviewChart($("reportChart"),6);
    const cats=getCategoryTotals(expensesForMonth()),total=sum(expensesForMonth());
    $("reportCategoryList").innerHTML=cats.length?cats.map(([name,value],i)=>`<div class="report-category"><span class="report-category-name">${escapeHTML(name)}</span><strong>${money(value)}</strong><div class="report-track"><span style="width:${total?value/total*100:0}%;background:${COLORS[i%COLORS.length]}"></span></div></div>`).join(""):'<p class="chart-placeholder">No expense data for this month yet.</p>';
    let insight="Add a few transactions to see a simple spending insight here.";
    if(exp>0&&monthlyBudget>0){const pct=exp/monthlyBudget*100;insight=pct>100?`You are ${money(exp-monthlyBudget)} over your monthly budget. Review non-essential spending and adjust your plan if needed.`:pct>=80?`You have used ${Math.round(pct)}% of your monthly budget. Keep an eye on upcoming expenses.`:`You have used ${Math.round(pct)}% of your monthly budget, leaving ${money(monthlyBudget-exp)} available.`;}
    else if(inc>0&&exp===0)insight="You have recorded income but no expenses this month. Add expenses as they happen to keep your balance realistic.";
    $("moneyInsight").textContent=insight;
  }
  function openTransactionModal(transaction){
    $("transactionForm").reset();$("formError").classList.add("hidden");$("transactionId").value=transaction?.id||"";
    $("transactionModalTitle").textContent=transaction?"Edit transaction":"Add transaction";
    $("saveTransactionBtn").textContent=transaction?"Save changes":"Save transaction";
    document.querySelector(`input[name="transactionType"][value="${transaction?.type||"expense"}"]`).checked=true;
    updateCategoryOptions(transaction?.category);
    $("transactionTitle").value=transaction?.title||"";$("transactionAmount").value=transaction?.amount??"";
    $("transactionDate").value=transaction?.date||todayISO();$("transactionNotes").value=transaction?.notes||"";
    $("transactionModal").classList.remove("hidden");document.body.style.overflow="hidden";setTimeout(()=>$("transactionTitle").focus(),30);
  }
  function closeModal(id){$(id).classList.add("hidden");if($("transactionModal").classList.contains("hidden")&&$("budgetModal").classList.contains("hidden"))document.body.style.overflow="";}
  function saveTransaction(event){
    event.preventDefault();const id=$("transactionId").value,title=$("transactionTitle").value.trim(),amount=Number($("transactionAmount").value),type=document.querySelector('input[name="transactionType"]:checked').value,date=$("transactionDate").value,category=$("transactionCategory").value,notes=$("transactionNotes").value.trim();
    if(!title||!date||!Number.isFinite(amount)||amount<=0){$("formError").textContent="Please enter a title, valid date, and amount greater than zero.";$("formError").classList.remove("hidden");return;}
    const old=transactions.find(t=>t.id===id);
    const item={id:id||makeId(),title,amount,type,date,category,notes,createdAt:old?.createdAt||new Date().toISOString()};
    if(id)transactions=transactions.map(t=>t.id===id?item:t);else transactions.push(item);
    save();closeModal("transactionModal");renderAll();showToast(id?"Transaction updated.":"Transaction saved.");
  }
  function handleTableAction(event){
    const edit=event.target.closest("[data-edit]"),del=event.target.closest("[data-delete]");
    if(edit){const t=transactions.find(x=>x.id===edit.dataset.edit);if(t)openTransactionModal(t);}
    if(del){const t=transactions.find(x=>x.id===del.dataset.delete);if(t&&confirm(`Delete "${t.title}"? This cannot be undone.`)){transactions=transactions.filter(x=>x.id!==t.id);save();renderAll();showToast("Transaction deleted.");}}
  }
  function exportCSV(){
    const rows=[["Title","Type","Category","Amount PHP","Date","Notes"],...transactions.slice().sort((a,b)=>a.date.localeCompare(b.date)).map(t=>[t.title,t.type,t.category,Number(t.amount).toFixed(2),t.date,t.notes||""])];
    const csv=rows.map(row=>row.map(v=>`"${String(v).replace(/"/g,'""')}"`).join(",")).join("\r\n");
    const blob=new Blob(["\uFEFF"+csv],{type:"text/csv;charset=utf-8;"}),url=URL.createObjectURL(blob),a=document.createElement("a");
    a.href=url;a.download=`spendwise-transactions-${todayISO()}.csv`;document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(url);showToast("CSV export downloaded.");
  }
  function navigate(view){
    const views=["dashboard","transactions","budgets","reports"];
    if(!views.includes(view))return;
    views.forEach(v=>$(v+"View").classList.toggle("hidden",v!==view));
    document.querySelectorAll(".nav-link[data-view]").forEach(b=>b.classList.toggle("active",b.dataset.view===view));
    $("breadcrumbPage").textContent=view[0].toUpperCase()+view.slice(1);
    $("sidebar").classList.remove("open");
    window.scrollTo({top:0,behavior:"smooth"});
  }
  function openBudgetModal(){ $("overallBudgetInput").value=monthlyBudget;$("budgetModal").classList.remove("hidden");document.body.style.overflow="hidden";setTimeout(()=>$("overallBudgetInput").focus(),30); }
  function saveBudget(e){e.preventDefault();const n=Number($("overallBudgetInput").value);if(!Number.isFinite(n)||n<0){showToast("Enter a valid budget amount.");return;}monthlyBudget=n;save();closeModal("budgetModal");renderAll();showToast("Monthly budget updated.");}
  function resetDemo(){
    if(confirm("Reset all transactions and budget to the original demo data? Your current prototype data will be replaced.")){transactions=demoTransactions();monthlyBudget=10000;save();renderAll();showToast("Demo data restored.");}
  }
  function init(){
    $("todayLabel").textContent=new Date().toLocaleDateString("en-PH",{month:"short",day:"numeric",year:"numeric"});
    $("yearLabel").textContent=new Date().getFullYear();
    $("addTransactionTop").addEventListener("click",()=>openTransactionModal());
    $("addTransactionPage").addEventListener("click",()=>openTransactionModal());
    $("closeTransactionModal").addEventListener("click",()=>closeModal("transactionModal"));
    $("cancelTransactionBtn").addEventListener("click",()=>closeModal("transactionModal"));
    $("transactionForm").addEventListener("submit",saveTransaction);
    document.querySelectorAll('input[name="transactionType"]').forEach(el=>el.addEventListener("change",()=>updateCategoryOptions()));
    $("transactionSearch").addEventListener("input",renderTransactions);$("typeFilter").addEventListener("change",renderTransactions);$("categoryFilter").addEventListener("change",renderTransactions);
    $("allTransactionsBody").addEventListener("click",handleTableAction);$("recentTransactionsBody").addEventListener("click",handleTableAction);
    $("exportCsvBtn").addEventListener("click",exportCSV);$("reportExportBtn").addEventListener("click",exportCSV);
    $("chartPeriod").addEventListener("change",()=>renderOverviewChart($("overviewChart"),Number($("chartPeriod").value)));
    $("setBudgetBtn").addEventListener("click",openBudgetModal);$("closeBudgetModal").addEventListener("click",()=>closeModal("budgetModal"));$("cancelBudgetBtn").addEventListener("click",()=>closeModal("budgetModal"));$("budgetForm").addEventListener("submit",saveBudget);
    $("resetDemoBtn").addEventListener("click",resetDemo);$("mobileMenuBtn").addEventListener("click",()=>$("sidebar").classList.toggle("open"));
    document.querySelectorAll("[data-view]").forEach(b=>b.addEventListener("click",()=>navigate(b.dataset.view)));
    document.querySelectorAll("[data-navigate]").forEach(b=>b.addEventListener("click",()=>navigate(b.dataset.navigate)));
    $("profileBtn").addEventListener("click",()=>showToast("Demo profile: Jonard Roselo. Authentication is not enabled in this prototype."));
    document.querySelectorAll(".modal-backdrop").forEach(backdrop=>backdrop.addEventListener("click",e=>{if(e.target===backdrop)closeModal(backdrop.id);}));
    document.addEventListener("keydown",e=>{if(e.key==="Escape"){closeModal("transactionModal");closeModal("budgetModal");$("sidebar").classList.remove("open");}});
    renderAll();
  }
  init();
})();
