SPENDWISE — PERSONAL EXPENSE AND BUDGET TRACKER
================================================

WHAT'S INCLUDED
---------------
index.html      Main responsive dashboard and dialogs
style.css       Modern blue theme and responsive layout
script.js       Working prototype behavior
database.sql    MySQL schema for a future PHP/MySQL backend
README.txt      Setup and usage guide

IMPORTANT PROTOTYPE NOTE
------------------------
This is a working front-end prototype. It stores transactions and the monthly
budget in your browser's localStorage. The data remains in that browser on
that device until browser storage is cleared. It is not a secure cloud account
and it does not currently connect to MySQL. database.sql is included so the
project has a ready database design for a later backend integration.

HOW TO RUN
----------
Option 1 — Open directly
1. Extract the ZIP file.
2. Open the project folder.
3. Double-click index.html or open it in your browser.
4. The dashboard should load with demo transactions.

Option 2 — Use Visual Studio Code
1. Extract the ZIP file.
2. Open the folder in Visual Studio Code.
3. If you have the Live Server extension, right-click index.html.
4. Select "Open with Live Server".

No npm install or build process is required.

FEATURES
--------
- Dashboard cards for total balance, monthly income, monthly expenses,
  and remaining monthly budget.
- Income and expense transactions: create, edit, and delete.
- Transaction categories, dates, and optional notes.
- Search and filter transaction history.
- Export transaction history as CSV.
- Set an overall monthly budget.
- Spending overview charts and category breakdown.
- Responsive layout for desktop, tablet, and mobile.
- Demo data and a reset-demo-data option.
- Philippine peso currency formatting.

HOW TO USE
----------
1. Open the dashboard.
2. Click "Add transaction".
3. Choose Expense or Income.
4. Enter a title, amount, category, date, and optional note.
5. Save the transaction. Dashboard totals and reports update automatically.
6. Open Budgets to set your monthly spending limit.
7. Open Transactions to search, filter, edit, delete, or export records.
8. Click "Reset demo data" in the sidebar if you want to restore the sample data.

DATABASE SETUP (OPTIONAL — FOR FUTURE BACKEND)
----------------------------------------------
The current front-end does not use MySQL. To create the included database:
1. Install XAMPP or another MySQL/MariaDB environment.
2. Start MySQL in the XAMPP Control Panel.
3. Open phpMyAdmin at http://localhost/phpmyadmin.
4. Select the SQL tab.
5. Import or paste the contents of database.sql and execute it.
6. The database spendwise_db and tables users, categories, transactions,
   and monthly_budgets will be created.

A future PHP backend will still be needed to connect this web interface to
MySQL. That would require API endpoints, server-side validation, authentication,
and changing script.js to request and save data through those endpoints.

SECURITY NOTES
--------------
- Do not use this localStorage prototype to store sensitive financial data.
- The prototype has no login, multi-user separation, server backups, or
  cloud synchronization.
- For a production version, use PHP prepared statements, password_hash() /
  password_verify(), authenticated server-side sessions, CSRF protection,
  server-side validation, HTTPS, and per-user authorization checks.

TROUBLESHOOTING
---------------
- If the design looks unstyled, ensure style.css is in the same folder as
  index.html and that the filename is exactly style.css.
- If buttons do not work, ensure script.js is in the same folder and that
  JavaScript is enabled in the browser.
- If demo data is missing, click Reset demo data. Browser storage may have
  been cleared or the page may be opened in a different browser/profile.
- An internet connection is only needed for the optional Google Fonts import;
  the application itself does not require an internet connection.

PROJECT FILE CONNECTION
-----------------------
index.html includes:
  <link rel="stylesheet" href="style.css">
  <script src="script.js"></script>

Keep all three files in the same project folder.
